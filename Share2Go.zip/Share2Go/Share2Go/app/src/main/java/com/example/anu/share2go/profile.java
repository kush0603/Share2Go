package com.example.anu.share2go;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class profile extends AppCompatActivity {
    com.example.anu.share2go.JSONParser jsonParser = new com.example.anu.share2go.JSONParser();
    private static String url_create_product = "http://172.16.81.62:8084/WebApplication2/profile.jsp";

    TextView name;
    TextView email;
    TextView phone;
    String userid = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
        name = (TextView) findViewById(R.id.name);
        email = (TextView) findViewById(R.id.email_show);
        phone = (TextView) findViewById(R.id.Phn_show);


        SharedPreferences prefs = getSharedPreferences("MyPref", MODE_PRIVATE);
        userid = prefs.getString("id", "0");

        new CreateNewProduct().execute();


    }

    class CreateNewProduct extends AsyncTask<String, String, String> {


        protected String doInBackground(String... args) {

            // Building Parameters
            List<NameValuePair> params = new ArrayList<NameValuePair>();
            params.add(new BasicNameValuePair("session", userid));

            JSONObject json1 = jsonParser.makeHttpRequest(url_create_product, "GET", params);
            String s = null;

            try {

                    final String name1 = json1.getString("name");
                    final String email1 = json1.getString("email");
                    final String phone1 = json1.getString("phone");
                Log.d("whatsapp", name1);
            }catch (Exception e) {
                // TODO Auto-generated catch block
                System.out.println("Exception"+e.getMessage());
                e.printStackTrace();
            }

            return json1.toString();
        }
        @Override
        protected void onPostExecute(String s)
        {

            try {
                JSONObject json=new JSONObject(s);

                name.setText(json.getString("name"));
                email.setText(json.getString("email"));
                phone.setText(json.getString("phone"));

            } catch (JSONException e) {
                e.printStackTrace();
            }

        }
    }
}

