package com.example.anu.share2go;

import android.content.SharedPreferences;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by Priya on 5/1/2016.
 */
public class change_c2c extends AppCompatActivity {

    com.example.anu.share2go.JSONParser jsonParser=new com.example.anu.share2go.JSONParser();
    private static String url_create_product = "http://172.16.81.62:8084/WebApplication2/update_c2c_car.jsp";
    private static String url_create_product1 = "http://172.16.81.62:8084/WebApplication2/update1_c2c.jsp";

    EditText model;
    EditText color;
    EditText car_number;
    EditText licence;
    String userid=null;
    Spinner sp;
    Button update;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change_cardtls);
        View backgroundimage = findViewById(R.id.back);
        Drawable background = backgroundimage.getBackground();
        background.setAlpha(80);

        update = (Button) findViewById(R.id.update);
        model = (EditText) findViewById(R.id.text2);
        color = (EditText) findViewById(R.id.text10);
        car_number = (EditText) findViewById(R.id.text4);
        licence = (EditText) findViewById(R.id.text6);
        sp = (Spinner) findViewById(R.id.spinner1);
        SharedPreferences prefs = getSharedPreferences("MyPref",MODE_PRIVATE);
        userid = prefs.getString("id","0");

        new CreateNewProduct().execute();
        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String model1=model.getText().toString();
                String color1=color.getText().toString();
                String cno=car_number.getText().toString();
                String licence1=licence.getText().toString();

                String seats=sp.getSelectedItem().toString();
                if(validateNumberPlate(cno) && validateLicence(licence1) && !model1.equals("") && !seats.equals("") && !color1.equals("")) {
                    new CreateNewProduct1().execute();
                }
                else {

                    //Toast.makeText(getApplicationContext(), "Invalid details", Toast.LENGTH_SHORT).show();

                }
            }
        });




    }

    class CreateNewProduct extends AsyncTask<String, String, String> {



        protected String doInBackground(String... args) {

            // Building Parameters
            List<NameValuePair> params = new ArrayList<NameValuePair>();
            params.add(new BasicNameValuePair("session", userid));

            JSONObject json = jsonParser.makeHttpRequest(url_create_product, "GET", params);

            String s=null;


            try {
                s= json.getString("result");
                Log.d("Msg", json.getString("result"));
                final String model1=json.getString("model");
                final String color1=json.getString("color");
                final String car_number1=json.getString("car_number");
                final String licence1=json.getString("licence");
                final int free_seat1=json.getInt("seats");
                if(s.equals("success")){
                    runOnUiThread(new Runnable() {

                        public void run() {
                            model.setText(model1);
                            color.setText(color1);
                            car_number.setText(car_number1);
                            licence.setText(licence1);
                            sp.setSelection(free_seat1);


                        }
                    });



                }
                else{

                    runOnUiThread(new Runnable() {

                        public void run() {

                            Toast.makeText(getApplicationContext(), "Error!!", Toast.LENGTH_SHORT).show();

                        }
                    });

                }

            } catch (Exception e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }

            return null;
        }
    }


    class CreateNewProduct1 extends AsyncTask<String, String, String> {



        protected String doInBackground(String... args) {

            // Building Parameters
            List<NameValuePair> params = new ArrayList<NameValuePair>();
            params.add(new BasicNameValuePair("model", model.getText().toString()));
            params.add(new BasicNameValuePair("color", color.getText().toString()));
            params.add(new BasicNameValuePair("car_number", car_number.getText().toString()));
            params.add(new BasicNameValuePair("licence", licence.getText().toString()));
            params.add(new BasicNameValuePair("seats",sp.getSelectedItem().toString()));
            params.add(new BasicNameValuePair("session", userid));


            JSONObject json = jsonParser.makeHttpRequest(url_create_product1, "GET", params);

            String s=null;

            try {
                s= json.getString("result");
                Log.d("Msg", json.getString("result"));
                if(s.equals("success")){
                    finish();
                    onBackPressed();
                    runOnUiThread(new Runnable() {

                        public void run() {

                            Toast.makeText(getBaseContext(), "Updated successful", Toast.LENGTH_SHORT).show();

                        }
                    });

                    finish();
                }
                else{
                    runOnUiThread(new Runnable() {

                        public void run() {

                            Toast.makeText(getApplicationContext(), "Not Updated", Toast.LENGTH_SHORT).show();

                        }
                    });
                }
            } catch (Exception e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }

            return null;
        }
    }

    private boolean validateNumberPlate(String number) {
        String NUMBER_PATTERN = "^[A-Z]{2}[ -][0-9]{1,2}(?: [A-Z])?(?: [A-Z]*)? [0-9]{4}$";

        Pattern pattern = Pattern.compile(NUMBER_PATTERN);
        Matcher matcher = pattern.matcher(number);
        return matcher.matches();
    }

    private boolean validateLicence(String number) {
        String NUMBER_PATTERN = "^[A-Z]\\d{2}-\\d{2}-\\d{6}$";

        Pattern pattern = Pattern.compile(NUMBER_PATTERN);
        Matcher matcher = pattern.matcher(number);
        return matcher.matches();
    }


}

