package com.example.anu.share2go;

import android.app.ProgressDialog;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.ListView;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by LENOVO on 30/04/2016.
 */
public class show_offer_c2c extends AppCompatActivity {

    String userid;
    JSONParser jsonParser = new JSONParser();
    private ProgressDialog progressDialog;
    CustomList customList = null;
    List<String> date = new ArrayList<String>();
    List<String> source = new ArrayList<String>();
    List<String> cost = new ArrayList<String>();
    List<String> names = new ArrayList<String>();
    List<String> seats = new ArrayList<String>();
    List<String> destination = new ArrayList<String>();
    private ListView listView;
    private static String url_create_product = "http://172.16.81.62:8084/WebApplication2/show_offer_c2c_final.jsp";
    private static JSONArray ja = null;
    private static JSONArray j = null;
    private static JSONObject jobj = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.list_of_rides);
        new CreateNewProduct().execute();
    }

    class CreateNewProduct extends AsyncTask<String, String, String> {

        /**
         * Before starting background thread Show Progress Dialog
         */
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressDialog = new ProgressDialog(show_offer_c2c.this);
            progressDialog.setCancelable(true);
            progressDialog.setMessage("Loading...");
            progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
            progressDialog.setProgress(0);
            progressDialog.show();
        }


        /**
         * Creating product
         */

        protected String doInBackground(String... args) {

            SharedPreferences prefs = getSharedPreferences("MyPref", MODE_PRIVATE);
            userid = prefs.getString("id", "0");
            List<NameValuePair> params = new ArrayList<NameValuePair>();
            params.add(new BasicNameValuePair("session", userid));
            jobj = jsonParser.makeHttpRequest(url_create_product, "GET", params);
            Log.d("wassup", jobj.toString());

            try {


                ja = jobj.getJSONArray("count");
                //Log.d("jarray",ja.toString());
                //Log.d("jarray[1]", String.valueOf(ja.length()));

                for (int i = 0; i < ja.length(); i++) {

                    String name="";
                    //Log.d("members", j.toString());
                    for(int j=0;j<ja.getJSONObject(i).getJSONArray("members").length();j++){
                        String members=ja.getJSONObject(i).getJSONArray("members").getJSONObject(j).get("full_name").toString();
                        String contact=ja.getJSONObject(i).getJSONArray("members").getJSONObject(j).get("phone").toString();
                        String src=ja.getJSONObject(i).getJSONArray("members").getJSONObject(j).get("source").toString();
                        String to=ja.getJSONObject(i).getJSONArray("members").getJSONObject(j).get("destination").toString();
                        int c=j+1;
                        name=name+c+".  "+members+"\n\t\t\t\tContact:  "+contact+"\n\t\t\t\tFrom:   "+src+"\n\t\t\t\tTo:   "+to+"\n";
                        //name=name+members+" , ";
                    }
                    date.add(ja.getJSONObject(i).get("date").toString());
                    source.add("Source :  " + ja.getJSONObject(i).get("source").toString());
                    cost.add(ja.getJSONObject(i).get("cost").toString()+"/person");
                    names.add(name);
                    seats.add("Seats available: "+ja.getJSONObject(i).get("seats").toString());
                    destination.add("Destination :  "+ja.getJSONObject(i).get("destination").toString());
                }

                customList = new CustomList(show_offer_c2c.this, date,seats, cost,source, names, destination);
                runOnUiThread(new Runnable() {

                    public void run() {

                        listView = (ListView) findViewById(R.id.listView);
                        listView.setAdapter(customList);

                    }
                });


            } catch (JSONException e) {
                e.printStackTrace();
            }
            return null;
        }
        @Override
        protected  void onPostExecute(String result)
        {
            progressDialog.dismiss();

        }
    }
}





