package com.example.anu.share2go;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;


public class accept_carpool_list extends AppCompatActivity {
    JSONParser jsonParser=new JSONParser();
    private static String url_create_product = "http://172.16.81.62:8084/WebApplication2/accept_ride.jsp";
    private static String url_create_product1 = "http://172.16.81.62:8084/WebApplication2/reject_ride.jsp";

    String jsonString;
    private ListView listView;
    private static  JSONObject json = null;
    private static JSONArray ja=null;
    List<String> startDate = new ArrayList<String>();
    List<String> name = new ArrayList<String>();
    List<String> endDate = new ArrayList<String>();
    List<String> source = new ArrayList<String>();
    List<String> seats = new ArrayList<String>();
    List<String> destination = new ArrayList<String>();
    private static int index=0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.list_of_rides);

        String data=getIntent().getStringExtra("list_details");

        try {

            json = new JSONObject(data);
            ja = json.getJSONArray("members");

           // Log.d("jarray[1]", String.valueOf(ja.length()));
            CustomList customList = null;
            for(int i=0;i<ja.length();i++) {
                startDate.add("From: "+ja.getJSONObject(i).get("date").toString());
                name.add("NAME: "+ja.getJSONObject(i).get("full_name").toString());
                endDate.add("To: "+ja.getJSONObject(i).get("end_date").toString());
                source.add("Source: "+ja.getJSONObject(i).get("source").toString());
                seats.add("");
                destination.add("Destination: "+ja.getJSONObject(i).get("destination").toString());


            }
            customList = new CustomList(this, startDate,endDate,seats,name,destination,source);
            listView = (ListView) findViewById(R.id.listView);
            listView.setAdapter(customList);

        } catch (JSONException e) {
            e.printStackTrace();
        }



        listView.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                index=i;
                Toast.makeText(getApplicationContext(), "You Clicked " + i, Toast.LENGTH_SHORT).show();
                AlertDialog.Builder builder1 = new AlertDialog.Builder(accept_carpool_list.this);
                builder1.setMessage("Accept/Reject Ride");
                builder1.setCancelable(true);

                builder1.setPositiveButton(
                        "Accept",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                new CreateNewProduct().execute();
                                dialog.cancel();

                            }
                        });

                builder1.setNegativeButton(
                        "Reject",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                new CreateNewProduct1().execute();

                                dialog.cancel();
                            }
                        });

                AlertDialog alert11 = builder1.create();
                alert11.show();



            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        //getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
       /* if (id == R.id.action_settings) {
            return true;
        }
            */
        return super.onOptionsItemSelected(item);
    }
    class CreateNewProduct extends AsyncTask<String, String, String> {

        @Override

        protected String doInBackground(String... args) {

            // Building Parameters

            List<NameValuePair> params = new ArrayList<NameValuePair>();
            try {
                params.add(new BasicNameValuePair("offer_id",json.get("offer_id").toString()));
                params.add(new BasicNameValuePair("take_id",ja.getJSONObject(index).get("take_id").toString()));
                params.add(new BasicNameValuePair("sdate",ja.getJSONObject(index).get("date").toString()));
                params.add(new BasicNameValuePair("end_date",ja.getJSONObject(index).get("end_date").toString()));
                params.add(new BasicNameValuePair("uid",ja.getJSONObject(index).get("uid").toString()));


            } catch (JSONException e) {
                e.printStackTrace();
            }


            JSONObject json = jsonParser.makeHttpRequest(url_create_product, "GET", params);

            String s = null;

            try {
                s = json.getString("result");
                Log.d("Msg", json.getString("result"));
                if (s.equals("success")) {
                    runOnUiThread(new Runnable() {

                        public void run() {

                            Toast.makeText(getApplicationContext(), "Successfully Accepted", Toast.LENGTH_SHORT).show();

                            Intent d = new Intent(accept_carpool_list.this, select_Ride.class);
                            startActivity(d);
                            finish();
                        }
                    });


                    finish();
                } else {
                    runOnUiThread(new Runnable() {

                        public void run() {

                            Toast.makeText(getApplicationContext(), "Error!!!", Toast.LENGTH_SHORT).show();

                        }
                    });


                }
            } catch (Exception e1) {
                // TODO Auto-generated catch block
                e1.printStackTrace();
            }

            return null;
        }

    }

    class CreateNewProduct1 extends AsyncTask<String, String, String> {

        @Override

        protected String doInBackground(String... args) {

            // Building Parameters

            List<NameValuePair> params = new ArrayList<NameValuePair>();
            try {
                params.add(new BasicNameValuePair("take_id",ja.getJSONObject(index).get("take_id").toString()));


            } catch (JSONException e) {
                e.printStackTrace();
            }


            JSONObject json = jsonParser.makeHttpRequest(url_create_product1, "GET", params);

            String s = null;

            try {
                s = json.getString("result");
                Log.d("Msg", json.getString("result"));
                if (s.equals("success")) {
                    runOnUiThread(new Runnable() {

                        public void run() {

                            Toast.makeText(getApplicationContext(), "Successfully Rejected", Toast.LENGTH_SHORT).show();

                            Intent d = new Intent(accept_carpool_list.this, select_Ride.class);
                            startActivity(d);
                            finish();
                        }
                    });


                    finish();
                } else {
                    runOnUiThread(new Runnable() {

                        public void run() {

                            Toast.makeText(getApplicationContext(), "Error!!!", Toast.LENGTH_SHORT).show();

                        }
                    });


                }
            } catch (Exception e1) {
                // TODO Auto-generated catch block
                e1.printStackTrace();
            }

            return null;
        }

    }
    }