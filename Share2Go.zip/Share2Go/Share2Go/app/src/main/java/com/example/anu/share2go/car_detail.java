package com.example.anu.share2go;

/**
 * Created by Priya on 4/20/2016.
 */
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class car_detail extends AppCompatActivity {
    com.example.anu.share2go.JSONParser jsonParser=new com.example.anu.share2go.JSONParser();
    private static String url_create_product = "http://172.16.81.62:8084/WebApplication2/car.jsp";
    EditText model;
    EditText color;
    EditText car_number;
    EditText licence;
    String userid=null;
    Spinner sp;
    String model1;
    String color1;
    String cno;
    String licence1;
    String seats;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.car_detail);
        View backgroundimage = findViewById(R.id.back);
        Drawable background = backgroundimage.getBackground();
        background.setAlpha(80);

        Button login = (Button) findViewById(R.id.login);
        model = (EditText) findViewById(R.id.text2);
        color = (EditText) findViewById(R.id.text10);
        car_number = (EditText) findViewById(R.id.text4);
        licence = (EditText) findViewById(R.id.text6);
        sp = (Spinner) findViewById(R.id.spinner1);


        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPreferences prefs = getSharedPreferences("MyPref",MODE_PRIVATE);
                userid = prefs.getString("id","0");
                 model1=model.getText().toString();
                color1=color.getText().toString();
                 cno=car_number.getText().toString();
                 licence1=licence.getText().toString();
                 seats=sp.getSelectedItem().toString();
                if(validateNumberPlate(cno) && validateLicence(licence1) && !model1.equals("") && !seats.equals("") && !color1.equals("")) {
                    new CreateNewProduct().execute();
                }
                else {

                    Toast.makeText(getApplicationContext(), "Invalid details", Toast.LENGTH_SHORT).show();

                }
            }
        });

    }
    class CreateNewProduct extends AsyncTask<String, String, String> {



        protected String doInBackground(String... args) {

            // Building Parameters
            List<NameValuePair> params = new ArrayList<NameValuePair>();
            params.add(new BasicNameValuePair("model", model1));
            params.add(new BasicNameValuePair("color", color1));
            params.add(new BasicNameValuePair("car_number", cno));
            params.add(new BasicNameValuePair("licence", licence1));
            params.add(new BasicNameValuePair("seats",seats));
            params.add(new BasicNameValuePair("session", userid));


            JSONObject json = jsonParser.makeHttpRequest(url_create_product, "GET", params);

            String s=null;

            try {
                s= json.getString("result");
                Log.d("Msg", json.getString("result"));
                if(s.equals("success")){
                    Intent login = new Intent(car_detail.this,Offer_Ride.class);
                    startActivity(login);
                    runOnUiThread(new Runnable() {

                        public void run() {

                            Toast.makeText(getBaseContext(), "car registration successful", Toast.LENGTH_SHORT).show();

                        }
                    });

                    finish();
                }
                else{
                    runOnUiThread(new Runnable() {

                        public void run() {

                            Toast.makeText(getApplicationContext(), "car registration unsuccessful", Toast.LENGTH_SHORT).show();

                        }
                    });
                   }
            } catch (Exception e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }

            return null;
        }
    }



    private boolean validateNumberPlate(String number) {
        String NUMBER_PATTERN = "^[A-Z]{2}[ -][0-9]{1,2}(?: [A-Z])?(?: [A-Z]*)? [0-9]{4}$";

        Pattern pattern = Pattern.compile(NUMBER_PATTERN);
        Matcher matcher = pattern.matcher(number);
        return matcher.matches();
    }

    private boolean validateLicence(String number) {
        String NUMBER_PATTERN = "^[A-Z]\\d{2}-\\d{2}-\\d{6}$";

        Pattern pattern = Pattern.compile(NUMBER_PATTERN);
        Matcher matcher = pattern.matcher(number);
        return matcher.matches();
    }

}
